"""Gera o PDF de um roteiro Roteiros Collab em formato de storyboard.

Uso: python gerar_pdf.py roteiro.json saida.pdf

Layout: cabeçalho com título, descrição, formato, duração e ideia central;
depois, para cada ato, uma tabela de duas colunas: à esquerda a fala de cada
parte, à direita a referência visual com um quadro desenhado em estilo rascunho.

Formato do JSON:
{
  "titulo": "...", "descricao": "...", "formato": "...", "duracao": "...",
  "ideia_central": "...", "parceiro": "..." (opcional),
  "atos": [
    {"nome": "1º ATO: Apresentação",
     "partes": [{"rotulo": "Gancho", "fala": "...", "tela": "TEXTO NA TELA",
                 "visual": {"plano": "close_rosto", "descricao": "...", "movimento": "zoom in"}}]}
  ]
}

Planos disponíveis em visual.plano: close_rosto, close_olho, plano_medio,
plano_geral, maos_objeto, celular, texto_tela, arquivo, grafico, dialogo, objeto.
"""
import json
import math
import os
import random
import sys
from datetime import date
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (Flowable, KeepTogether, Paragraph,
                                SimpleDocTemplate, Spacer, Table, TableStyle)

INK = colors.HexColor("#1A1A1A")
MUTED = colors.HexColor("#6B6B6B")
ACCENT = colors.HexColor("#E8452C")
CARD = colors.HexColor("#F5F3EF")
LINE = colors.HexColor("#DCD7CD")
PENCIL = colors.HexColor("#2B2B2B")
SHADE = colors.HexColor("#D9D4CA")
PAPER = colors.HexColor("#FBFAF7")
HIGHLIGHT = colors.HexColor("#F7D046")
ACT_COLORS = [colors.HexColor("#2F6FDE"), colors.HexColor("#E8452C"), colors.HexColor("#1E9E6A")]

S = {
    "kicker": ParagraphStyle("k", fontName="Helvetica-Bold", fontSize=8, leading=10, textColor=ACCENT),
    "title": ParagraphStyle("t", fontName="Helvetica-Bold", fontSize=22, leading=26, textColor=INK),
    "desc": ParagraphStyle("d", fontName="Helvetica", fontSize=10.5, leading=14.5, textColor=INK),
    "infolabel": ParagraphStyle("il", fontName="Helvetica-Bold", fontSize=7, leading=9, textColor=MUTED),
    "infoval": ParagraphStyle("iv", fontName="Helvetica-Bold", fontSize=10, leading=12.5, textColor=INK),
    "idea": ParagraphStyle("i", fontName="Helvetica-Oblique", fontSize=10.5, leading=14, textColor=INK),
    "act": ParagraphStyle("a", fontName="Helvetica-Bold", fontSize=12, leading=15, textColor=colors.white),
    "colhead": ParagraphStyle("ch", fontName="Helvetica-Bold", fontSize=7.5, leading=9, textColor=MUTED),
    "label": ParagraphStyle("l", fontName="Helvetica-Bold", fontSize=10.5, leading=13, textColor=INK),
    "speech": ParagraphStyle("s", fontName="Helvetica", fontSize=10.5, leading=15, textColor=INK),
    "note": ParagraphStyle("n", fontName="Helvetica", fontSize=8.5, leading=11.5, textColor=MUTED),
    "vis": ParagraphStyle("v", fontName="Helvetica", fontSize=8.5, leading=11.5, textColor=INK),
    "hooktag": ParagraphStyle("ht", fontName="Helvetica-Bold", fontSize=7.5, leading=9.5, textColor=colors.HexColor("#2F6FDE")),
    "copy": ParagraphStyle("cp", fontName="Helvetica-Bold", fontSize=10.5, leading=14, textColor=colors.HexColor("#D9372B")),
    "visplano": ParagraphStyle("vp", fontName="Helvetica-Bold", fontSize=7.5, leading=9.5, textColor=ACCENT),
}

PLANO_NOMES = {
    "close_rosto": "CLOSE NO ROSTO", "close_olho": "SUPER CLOSE", "plano_medio": "PLANO MÉDIO",
    "plano_geral": "PLANO GERAL", "maos_objeto": "DETALHE DAS MÃOS", "celular": "TELA / CELULAR",
    "texto_tela": "TEXTO NA TELA", "arquivo": "IMAGEM DE ARQUIVO", "grafico": "GRÁFICO / DADO",
    "dialogo": "DIÁLOGO", "objeto": "DETALHE DE OBJETO",
    "pov_objeto": "POV DO OBJETO", "quarta_parede": "QUEBRA DA QUARTA PAREDE", "minhoca": "ÂNGULO DE MINHOCA",
    "snorricam": "SNORRICAM", "olho_de_peixe": "OLHO DE PEIXE", "de_cima": "DE CIMA (TOP-DOWN)",
    "ombro": "POR CIMA DO OMBRO", "tela_dividida": "TELA DIVIDIDA", "duplicacao": "DUPLICAÇÃO",
    "reflexo": "REFLEXO", "silhueta": "SILHUETA", "escala": "MUDANÇA DE ESCALA", "whip_pan": "WHIP PAN",
    "portal_objeto": "PORTAL / ATRAVESSAR", "dolly_zoom": "DOLLY ZOOM",
}


def p(text, style):
    return Paragraph(escape(text or "").replace("\n", "<br/>"), style)


FONT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets")
try:
    pdfmetrics.registerFont(TTFont("Marker", os.path.join(FONT_DIR, "PermanentMarker.ttf")))
    MARKER = "Marker"
except Exception:  # sem a fonte, usa uma fonte padrão
    MARKER = "Helvetica-BoldOblique"

RED = colors.HexColor("#D9372B")
GRAY = colors.HexColor("#8C8C8C")


class Sketch(Flowable):
    """Quadro vertical 9:16 no estilo de storyboard a mão: traço de nanquim,
    sombra de marcador cinza e anotações e setas de câmera em vermelho."""

    def __init__(self, plano, anotacao, movimento, tela, seed, width=40 * mm, horizontal=False):
        super().__init__()
        self.plano = plano if plano in PLANO_NOMES else "plano_medio"
        self.anotacao, self.movimento, self.tela = anotacao, movimento, tela
        self.w, self.h = width, width * (9 / 16 if horizontal else 16 / 9)
        self.k = self.w / self.h
        self.rnd = random.Random(seed)

    def wrap(self, aw, ah):
        return self.w, self.h

    def j(self, v=0.45):
        return self.rnd.uniform(-v, v)

    def X(self, x):
        return x * self.w

    def Y(self, y):
        return y * self.h

    # ---- traço de nanquim: um traço forte e um fino ao lado ----
    def stroke(self, pts, width=1.5, close=False):
        c = self.canv
        c.setStrokeColor(PENCIL)
        for wd, jit in ((width, 0.25), (width * 0.4, 0.7)):
            c.setLineWidth(wd)
            pa = c.beginPath()
            pa.moveTo(self.X(pts[0][0]) + self.j(jit), self.Y(pts[0][1]) + self.j(jit))
            for x, y in pts[1:]:
                pa.lineTo(self.X(x) + self.j(jit), self.Y(y) + self.j(jit))
            if close:
                pa.close()
            c.drawPath(pa, stroke=1, fill=0)

    def line(self, x1, y1, x2, y2, width=1.5):
        self.stroke([(x1, y1), (x2, y2)], width)

    def arc_pts(self, cx, cy, rx, ry, a0=0, a1=360, n=40):
        return [(cx + rx * math.cos(math.radians(a0 + (a1 - a0) * i / n)),
                 cy + ry * math.sin(math.radians(a0 + (a1 - a0) * i / n))) for i in range(n + 1)]

    def oval(self, cx, cy, rx, ry, width=1.5, a0=0, a1=360, fill=None):
        pts = self.arc_pts(cx, cy, rx, ry, a0, a1)
        if fill is not None:
            self.fill(pts, fill)
        self.stroke(pts, width, close=(a1 - a0) >= 360)

    def fill(self, pts, color, alpha=1.0):
        c = self.canv
        c.saveState()
        c.setFillColor(color)
        c.setFillAlpha(alpha)
        pa = c.beginPath()
        pa.moveTo(self.X(pts[0][0]), self.Y(pts[0][1]))
        for x, y in pts[1:]:
            pa.lineTo(self.X(x), self.Y(y))
        pa.close()
        c.drawPath(pa, stroke=0, fill=1)
        c.restoreState()

    # ---- sombra de marcador cinza ----
    def shade(self, pts, alpha=0.32):
        self.fill([(x + self.j(0.004), y + self.j(0.004)) for x, y in pts], GRAY, alpha)

    def shade_oval(self, cx, cy, rx, ry, a0=0, a1=360, alpha=0.32):
        self.shade(self.arc_pts(cx, cy, rx, ry, a0, a1), alpha)

    def room(self):
        # canto de parede em perspectiva, como fundo de cena
        self.line(0.0, 0.86, 0.3, 0.74, 0.9)
        self.line(0.3, 0.74, 0.3, 0.3, 0.9)
        self.line(0.3, 0.3, 0.0, 0.2, 0.9)
        self.line(0.3, 0.74, 1.0, 0.8, 0.9)
        self.line(0.3, 0.3, 1.0, 0.26, 0.9)

    # ---- personagens ----
    def head(self, cx, cy, r, detail=True):
        k = self.k
        self.shade_oval(cx + r * 0.25, cy - r * 0.1 * k, r * 0.6, r * 0.9 * k, -70, 80)
        self.oval(cx, cy, r * 0.8, r * 1.02 * k, width=1.6, fill=PAPER)
        self.shade_oval(cx + r * 0.32, cy - r * 0.08 * k, r * 0.45, r * 0.85 * k, -80, 80)
        # cabelo em cachos
        for i in range(9):
            ang = math.radians(15 + i * 18.75)
            hx, hy = cx + r * 0.82 * math.cos(ang), cy + r * 1.0 * k * math.sin(ang) + r * 0.08 * k
            self.oval(hx, hy, r * 0.17, r * 0.15 * k, width=1.3, fill=PAPER)
        if detail:
            ey = cy + r * 0.1 * k
            for sx in (-1, 1):
                ex = cx + sx * r * 0.32
                self.canv.setFillColor(PENCIL)
                self.canv.circle(self.X(ex), self.Y(ey), max(0.7, r * self.w * 0.05), stroke=0, fill=1)
                self.line(cx + sx * r * 0.14, ey + r * 0.2 * k, cx + sx * r * 0.5, ey + r * 0.27 * k, 1.6)
            self.stroke([(cx + r * 0.02, ey - r * 0.06 * k), (cx - r * 0.08, ey - r * 0.36 * k),
                         (cx + r * 0.06, ey - r * 0.4 * k)], 1.0)
            self.oval(cx, ey - r * 0.52 * k, r * 0.24, r * 0.1 * k, a0=200, a1=340, width=1.3)

    def body(self, cx, top, wsh, bottom):
        left = [(cx - 0.06, top + 0.015), (cx - 0.07, top - 0.02), (cx - wsh, top - 0.05), (cx - wsh - 0.04, bottom)]
        right = [(cx + 0.06, top + 0.015), (cx + 0.07, top - 0.02), (cx + wsh, top - 0.05), (cx + wsh + 0.04, bottom)]
        self.fill(left + right[::-1], colors.white)
        self.shade([(cx + 0.04, top - 0.03), (cx + wsh, top - 0.05), (cx + wsh + 0.04, bottom), (cx + 0.1, bottom)])
        self.stroke(left, 1.7)
        self.stroke(right, 1.7)
        self.line(cx - 0.03, top - 0.02, cx + 0.04, top - 0.1, 1.0)

    def figure(self, cx, base, height):
        k = self.k
        hr = height * 0.11
        hy = base + height - hr
        self.shade_oval(cx + 0.05, base, 0.12, 0.012)
        self.oval(cx, hy, hr / k * 0.8, hr, 1.3, fill=PAPER)
        neck, hip = hy - hr, base + height * 0.45
        arm = height * 0.2
        self.stroke([(cx, neck), (cx, hip)], 1.6)
        self.stroke([(cx - arm * 0.5, neck - height * 0.3), (cx, neck - height * 0.05), (cx + arm * 0.5, neck - height * 0.3)], 1.3)
        self.stroke([(cx - arm * 0.35, base), (cx, hip), (cx + arm * 0.35, base)], 1.4)

    def hand(self, x, y, sx):
        self.fill([(x, y), (x + sx * 0.12, y + 0.05), (x + sx * 0.16, y + 0.02), (x + sx * 0.14, y - 0.04),
                   (x + sx * 0.02, y - 0.06)], PAPER)
        self.stroke([(x, y), (x + sx * 0.12, y + 0.05), (x + sx * 0.16, y + 0.02), (x + sx * 0.14, y - 0.04),
                     (x + sx * 0.02, y - 0.06)], 1.4, close=True)
        for i in range(3):
            self.line(x + sx * 0.12, y + 0.02 - i * 0.02, x + sx * 0.16, y + 0.015 - i * 0.02, 0.8)

    # ---- planos ----
    def draw_close_rosto(self):
        self.room()
        self.head(0.52, 0.56, 0.34)
        self.body(0.52, 0.34, 0.34, 0.0)

    def draw_close_olho(self):
        k = self.k
        self.shade([(0.06, 0.5), (0.3, 0.42), (0.5, 0.39), (0.7, 0.42), (0.94, 0.5), (0.7, 0.36), (0.3, 0.36)])
        self.stroke([(0.06, 0.5), (0.3, 0.6), (0.5, 0.63), (0.7, 0.6), (0.94, 0.5)], 2.0)
        self.stroke([(0.06, 0.5), (0.3, 0.42), (0.5, 0.4), (0.7, 0.42), (0.94, 0.5)], 1.6)
        self.oval(0.5, 0.515, 0.17, 0.17 * k, 1.5, fill=PAPER)
        self.shade_oval(0.5, 0.515, 0.17, 0.17 * k, alpha=0.25)
        self.fill(self.arc_pts(0.5, 0.515, 0.08, 0.08 * k), PENCIL)
        self.canv.setFillColor(colors.white)
        self.canv.circle(self.X(0.54), self.Y(0.535), self.w * 0.025, stroke=0, fill=1)
        for i in range(9):
            x = 0.14 + i * 0.09
            b = 0.02 * math.sin(i / 8 * math.pi)
            self.line(x, 0.585 + b, x - 0.025, 0.625 + b, 0.9)
        self.stroke([(0.08, 0.7), (0.35, 0.77), (0.65, 0.77), (0.92, 0.7)], 3.0)
        self.shade([(0.0, 0.64), (1.0, 0.64), (1.0, 0.68), (0.0, 0.68)], 0.18)

    def draw_plano_medio(self):
        self.room()
        self.head(0.52, 0.68, 0.18)
        self.body(0.52, 0.53, 0.24, 0.0)
        self.hand(0.36, 0.25, 1)
        self.hand(0.68, 0.25, -1)
        self.oval(0.52, 0.27, 0.07, 0.04, 1.4, fill=PAPER)
        self.shade_oval(0.55, 0.26, 0.05, 0.03)

    def draw_plano_geral(self):
        self.line(0.0, 0.32, 1.0, 0.36, 1.2)
        for x, hgt in ((0.08, 0.3), (0.22, 0.42), (0.8, 0.34), (0.94, 0.24)):
            pts = [(x - 0.07, 0.33), (x - 0.07, 0.33 + hgt), (x + 0.07, 0.33 + hgt), (x + 0.07, 0.33)]
            self.shade([(x + 0.01, 0.33), (x + 0.01, 0.33 + hgt), (x + 0.07, 0.33 + hgt), (x + 0.07, 0.33)])
            self.stroke(pts, 1.2)
        self.stroke([(0.35, 0.0), (0.46, 0.33)], 0.9)
        self.stroke([(0.75, 0.0), (0.56, 0.34)], 0.9)
        self.figure(0.5, 0.22, 0.28)

    def draw_maos_objeto(self):
        self.shade([(0.32, 0.26), (0.76, 0.26), (0.8, 0.68), (0.72, 0.68)], 0.3)
        pts = [(0.28, 0.3), (0.7, 0.3), (0.74, 0.72), (0.32, 0.72)]
        self.fill(pts, PAPER)
        self.stroke(pts, 1.6, close=True)
        for i in range(5):
            self.line(0.36, 0.62 - i * 0.06, 0.66, 0.62 - i * 0.06, 0.6)
        self.hand(0.14, 0.42, 1)
        self.hand(0.88, 0.46, -1)
        self.stroke([(0.0, 0.3), (0.14, 0.4)], 1.6)
        self.stroke([(1.0, 0.34), (0.88, 0.44)], 1.6)
        self.line(0.0, 0.14, 1.0, 0.2, 1.0)
        self.shade([(0.0, 0.0), (1.0, 0.0), (1.0, 0.2), (0.0, 0.14)], 0.2)

    def draw_celular(self):
        self.shade([(0.28, 0.08), (0.84, 0.08), (0.84, 0.84), (0.78, 0.84)], 0.35)
        pts = [(0.22, 0.12), (0.78, 0.12), (0.78, 0.88), (0.22, 0.88)]
        self.fill(pts, PAPER)
        self.stroke(pts, 2.0, close=True)
        for i in range(4):
            y = 0.76 - i * 0.14
            box = [(0.29, y), (0.71, y), (0.71, y - 0.1), (0.29, y - 0.1)]
            if i % 2:
                self.shade(box, 0.3)
            self.stroke(box, 0.9, close=True)
        self.hand(0.86, 0.3, -1)

    def draw_texto_tela(self):
        self.shade([(0, 0), (1, 0), (1, 1), (0, 1)], 0.55)
        self.fill([(0.07, 0.36), (0.93, 0.36), (0.93, 0.64), (0.07, 0.64)], PAPER)
        self.stroke([(0.07, 0.36), (0.93, 0.36), (0.93, 0.64), (0.07, 0.64)], 1.4, close=True)

    def draw_arquivo(self):
        self.shade([(0.18, 0.16), (0.9, 0.16), (0.9, 0.76), (0.86, 0.76)], 0.3)
        self.fill([(0.12, 0.2), (0.84, 0.2), (0.84, 0.8), (0.12, 0.8)], colors.HexColor("#E6E2DA"))
        self.stroke([(0.12, 0.2), (0.84, 0.2), (0.84, 0.8), (0.12, 0.8)], 1.6, close=True)
        self.stroke([(0.17, 0.25), (0.79, 0.25), (0.79, 0.75), (0.17, 0.75)], 0.7, close=True)
        self.head(0.48, 0.57, 0.14, detail=False)
        self.body(0.48, 0.47, 0.14, 0.26)

    def draw_grafico(self):
        self.line(0.12, 0.2, 0.9, 0.2, 1.6)
        self.line(0.12, 0.2, 0.12, 0.8, 1.6)
        for x, hgt, a in ((0.33, 0.52, 0.6), (0.66, 0.14, 0.2)):
            pts = [(x - 0.11, 0.2), (x - 0.11, 0.2 + hgt), (x + 0.11, 0.2 + hgt), (x + 0.11, 0.2)]
            self.shade(pts, a)
            self.stroke(pts, 1.5)

    def draw_dialogo(self):
        self.room()
        self.head(0.27, 0.62, 0.16)
        self.body(0.27, 0.5, 0.17, 0.05)
        self.head(0.75, 0.58, 0.16)
        self.body(0.75, 0.46, 0.17, 0.05)

    def draw_objeto(self):
        self.shade([(0.0, 0.0), (1.0, 0.0), (1.0, 0.36), (0.0, 0.3)], 0.22)
        self.line(0.0, 0.3, 1.0, 0.36, 1.4)
        self.shade_oval(0.58, 0.33, 0.22, 0.03)
        pts = [(0.3, 0.33), (0.33, 0.62), (0.67, 0.62), (0.7, 0.34)]
        self.fill(pts, PAPER)
        self.shade([(0.55, 0.33), (0.6, 0.62), (0.67, 0.62), (0.7, 0.34)])
        self.stroke(pts, 1.7)
        self.oval(0.5, 0.62, 0.17, 0.03, 1.5)
        self.oval(0.76, 0.5, 0.08, 0.06, 1.5, a0=-80, a1=80)
        for i in range(3):
            self.stroke([(0.42 + i * 0.08, 0.68), (0.4 + i * 0.08, 0.74), (0.43 + i * 0.08, 0.8)], 0.8)

    # ---- takes criativos ----
    def dark(self, pts, alpha=0.75):
        self.fill(pts, PENCIL, alpha)

    def draw_pov_objeto(self):
        # de dentro da geladeira olhando para fora
        self.shade([(0, 0), (1, 0), (1, 1), (0, 1)], 0.55)
        hole = [(0.2, 0.22), (0.8, 0.22), (0.8, 0.82), (0.2, 0.82)]
        self.fill(hole, colors.white)
        for (a, b) in (((0, 0), (0.2, 0.22)), ((1, 0), (0.8, 0.22)), ((1, 1), (0.8, 0.82)), ((0, 1), (0.2, 0.82))):
            self.line(a[0], a[1], b[0], b[1], 1.3)
        self.line(0.0, 0.5, 0.2, 0.52, 1.0)
        self.line(1.0, 0.5, 0.8, 0.52, 1.0)
        self.head(0.5, 0.58, 0.17)
        self.body(0.5, 0.45, 0.2, 0.22)
        self.hand(0.82, 0.62, -1)
        self.stroke(hole, 1.8, close=True)
        carton = [(0.04, 0.0), (0.24, 0.0), (0.24, 0.3), (0.14, 0.36), (0.04, 0.3)]
        self.dark(carton, 0.8)
        self.stroke(carton, 1.2, close=True)

    def draw_quarta_parede(self):
        self.room()
        self.head(0.66, 0.8, 0.17)
        self.body(0.66, 0.68, 0.2, 0.45)
        # braço vindo da pessoa até a mão enorme em primeiro plano
        self.stroke([(0.5, 0.62), (0.42, 0.42)], 2.0)
        palm = self.arc_pts(0.4, 0.26, 0.3, 0.16)
        self.fill(palm, colors.white)
        self.shade_oval(0.48, 0.22, 0.2, 0.1)
        self.stroke(palm, 2.2, close=True)
        for fx, ln in ((0.16, 0.12), (0.3, 0.17), (0.44, 0.18), (0.58, 0.14)):
            f = [(fx - 0.055, 0.36), (fx - 0.05, 0.36 + ln), (fx + 0.05, 0.37 + ln), (fx + 0.055, 0.35)]
            self.fill(f, colors.white)
            self.stroke(f, 2.0)
        self.stroke([(0.66, 0.24), (0.84, 0.34), (0.88, 0.28), (0.7, 0.16)], 2.0)
        self.line(0.24, 0.2, 0.5, 0.16, 0.9)

    def draw_minhoca(self):
        for x in (0.0, 1.0):
            self.line(x, 0.0, 0.5, 1.05, 0.9)
        self.line(0.15, 0.0, 0.42, 1.0, 0.7)
        self.line(0.85, 0.0, 0.58, 1.0, 0.7)
        for sx in (-1, 1):
            shoe = self.arc_pts(0.5 + sx * 0.2, 0.08, 0.18, 0.07)
            self.dark(shoe, 0.85)
            self.stroke(shoe, 1.8, close=True)
            leg = [(0.5 + sx * 0.14, 0.13), (0.5 + sx * 0.05, 0.5), (0.5 + sx * 0.25, 0.13)]
            self.fill(leg, colors.white)
            self.stroke(leg, 1.6)
        torso = [(0.4, 0.5), (0.36, 0.72), (0.64, 0.72), (0.6, 0.5)]
        self.fill(torso, colors.white)
        self.shade([(0.52, 0.5), (0.55, 0.72), (0.64, 0.72), (0.6, 0.5)])
        self.stroke(torso, 1.6, close=True)
        self.oval(0.5, 0.79, 0.08, 0.045, 1.5, fill=PAPER)
        self.stroke([(0.36, 0.7), (0.24, 0.6), (0.3, 0.52)], 1.4)
        self.stroke([(0.64, 0.7), (0.76, 0.6), (0.7, 0.52)], 1.4)

    def draw_snorricam(self):
        for i in range(9):
            y = 0.1 + i * 0.1
            self.line(0.0, y, 0.22, y + 0.06, 0.7)
            self.line(0.78, y + 0.06, 1.0, y + 0.12, 0.7)
        self.shade([(0, 0), (0.2, 0), (0.2, 1), (0, 1)], 0.25)
        self.shade([(0.8, 0), (1, 0), (1, 1), (0.8, 1)], 0.25)
        self.head(0.5, 0.6, 0.27)
        self.body(0.5, 0.42, 0.3, 0.0)
        rig = [(0.5, 0.0), (0.5, 0.2)]
        self.stroke(rig, 2.6)
        self.stroke([(0.38, 0.2), (0.62, 0.2)], 2.6)

    def draw_olho_de_peixe(self):
        k = self.k
        self.shade([(0, 0), (1, 0), (1, 1), (0, 1)], 0.6)
        lens = self.arc_pts(0.5, 0.5, 0.56, 0.47)
        self.fill(lens, colors.white)
        self.stroke(self.arc_pts(0.5, 0.22, 0.6, 0.12, 200, 340), 1.0)
        self.head(0.5, 0.55, 0.42)
        self.oval(0.48, 0.5, 0.12, 0.06, 1.6, fill=PAPER)
        self.stroke(lens, 2.0, close=True)

    def draw_de_cima(self):
        k = self.k
        self.shade([(0, 0), (1, 0), (1, 1), (0, 1)], 0.1)
        # pessoa vista de cima, na borda de cima do quadro
        sh = self.arc_pts(0.5, 1.0, 0.42, 0.12, 180, 360)
        self.fill(sh, colors.white)
        self.shade_oval(0.62, 0.95, 0.2, 0.06, 180, 360)
        self.stroke(sh, 1.8)
        for i in range(10):
            a = math.radians(190 + i * 16)
            self.oval(0.5 + 0.15 * math.cos(a), 1.0 + 0.15 * k * math.sin(a), 0.06, 0.033, 1.2, fill=PAPER)
        self.stroke([(0.14, 0.94), (0.2, 0.7), (0.3, 0.58)], 1.7)
        self.stroke([(0.86, 0.94), (0.8, 0.7), (0.7, 0.58)], 1.7)
        # caderno aberto no centro
        book = [(0.22, 0.24), (0.78, 0.24), (0.78, 0.58), (0.22, 0.58)]
        self.shade([(0.26, 0.2), (0.82, 0.2), (0.82, 0.54), (0.78, 0.54)], 0.4)
        self.fill(book, colors.white)
        self.stroke(book, 1.7, close=True)
        self.line(0.5, 0.24, 0.5, 0.58, 1.1)
        for i in range(4):
            self.line(0.27, 0.5 - i * 0.06, 0.45, 0.5 - i * 0.06, 0.5)
        for (x, y) in ((0.58, 0.48), (0.66, 0.4), (0.58, 0.32)):
            self.stroke([(x, y), (x + 0.06, y), (x + 0.06, y - 0.05), (x, y - 0.05)], 0.9, close=True)
        self.hand(0.2, 0.56, 1)
        self.hand(0.8, 0.56, -1)
        # caneca e celular
        self.oval(0.84, 0.14, 0.08, 0.045, 1.5, fill=PAPER)
        self.shade_oval(0.84, 0.14, 0.055, 0.03, alpha=0.65)
        self.stroke(self.arc_pts(0.93, 0.14, 0.03, 0.02, -90, 90), 1.3)
        ph = [(0.08, 0.06), (0.22, 0.06), (0.22, 0.2), (0.08, 0.2)]
        self.dark(ph, 0.75)
        self.stroke(ph, 1.2, close=True)

    def draw_ombro(self):
        self.room()
        self.head(0.66, 0.62, 0.15)
        self.body(0.66, 0.51, 0.16, 0.12)
        back = self.arc_pts(0.2, 0.6, 0.32, 0.2)
        self.dark(back, 0.85)
        self.stroke(back, 1.8, close=True)
        sh = [(-0.1, 0.0), (-0.1, 0.4), (0.25, 0.42), (0.5, 0.3), (0.55, 0.0)]
        self.dark(sh, 0.8)
        self.stroke(sh, 1.8)

    def draw_tela_dividida(self):
        self.head(0.5, 0.8, 0.17)
        self.body(0.5, 0.68, 0.2, 0.52)
        self.shade([(0, 0), (1, 0), (1, 0.5), (0, 0.5)], 0.3)
        self.head(0.5, 0.3, 0.17)
        self.body(0.5, 0.18, 0.2, 0.0)
        self.stroke([(0.0, 0.5), (1.0, 0.5)], 2.6)

    def draw_duplicacao(self):
        self.line(0.0, 0.25, 1.0, 0.28, 1.0)
        for cx, h in ((0.2, 0.42), (0.5, 0.5), (0.8, 0.42)):
            self.figure(cx, 0.24 if cx != 0.5 else 0.2, h)

    def draw_reflexo(self):
        mirror = [(0.16, 0.3), (0.84, 0.3), (0.84, 0.92), (0.16, 0.92)]
        self.shade(mirror, 0.3)
        self.stroke(mirror, 1.8, close=True)
        self.head(0.5, 0.66, 0.17)
        self.body(0.5, 0.55, 0.19, 0.3)
        for i in range(3):
            self.line(0.66 + i * 0.05, 0.86, 0.78 + i * 0.05, 0.74, 0.6)
        back = self.arc_pts(0.32, 0.12, 0.3, 0.17)
        self.dark(back, 0.85)
        self.stroke(back, 1.8, close=True)

    def draw_silhueta(self):
        self.shade([(0, 0), (1, 0), (1, 1), (0, 1)], 0.5)
        win = [(0.14, 0.2), (0.86, 0.2), (0.86, 0.88), (0.14, 0.88)]
        self.fill(win, colors.white)
        self.stroke(win, 1.6, close=True)
        self.line(0.5, 0.2, 0.5, 0.88, 1.2)
        self.line(0.14, 0.54, 0.86, 0.54, 1.2)
        k = self.k
        self.fill(self.arc_pts(0.47, 0.66, 0.1, 0.1 * k), PENCIL)
        self.fill([(0.3, 0.0), (0.32, 0.48), (0.4, 0.58), (0.52, 0.58), (0.6, 0.48), (0.64, 0.0)], PENCIL)

    def draw_escala(self):
        book = [(0.04, 0.06), (0.96, 0.14), (0.86, 0.5), (0.14, 0.44)]
        self.fill(book, colors.white)
        self.shade([(0.5, 0.1), (0.96, 0.14), (0.86, 0.5), (0.5, 0.47)], 0.2)
        self.stroke(book, 2.0, close=True)
        for i in range(5):
            self.line(0.2 + i * 0.02, 0.18 + i * 0.05, 0.84 - i * 0.02, 0.24 + i * 0.05, 0.6)
        self.figure(0.5, 0.36, 0.2)
        self.shade_oval(0.54, 0.36, 0.06, 0.01, alpha=0.5)
        pen = [(0.7, 0.98), (0.76, 1.0), (0.6, 0.5), (0.56, 0.52)]
        self.dark(pen, 0.7)
        self.stroke(pen, 1.6, close=True)

    def draw_whip_pan(self):
        for i in range(26):
            y = 0.04 + i * 0.037
            x0 = self.rnd.uniform(0.0, 0.3)
            self.line(x0, y, x0 + self.rnd.uniform(0.4, 0.7), y + self.rnd.uniform(-0.005, 0.005), 0.8)
        self.shade([(0, 0.3), (1, 0.34), (1, 0.7), (0, 0.66)], 0.25)
        self.head(0.86, 0.6, 0.15, detail=False)

    def draw_portal_objeto(self):
        self.shade([(0, 0), (1, 0), (1, 1), (0, 1)], 0.65)
        ring = self.arc_pts(0.5, 0.5, 0.44, 0.25)
        self.fill(ring, colors.white)
        self.stroke(self.arc_pts(0.5, 0.5, 0.48, 0.27), 2.2, close=True)
        self.stroke(ring, 1.4, close=True)
        self.line(0.12, 0.44, 0.88, 0.46, 1.0)
        self.figure(0.5, 0.36, 0.22)
        for x in (0.22, 0.76):
            self.stroke([(x - 0.05, 0.45), (x - 0.05, 0.58), (x + 0.05, 0.58), (x + 0.05, 0.45)], 1.0)

    def draw_dolly_zoom(self):
        back = [(0.34, 0.4), (0.66, 0.4), (0.66, 0.66), (0.34, 0.66)]
        self.stroke(back, 1.2, close=True)
        for a, b in (((0, 0), (0.34, 0.4)), ((1, 0), (0.66, 0.4)), ((1, 1), (0.66, 0.66)), ((0, 1), (0.34, 0.66))):
            self.line(a[0], a[1], b[0], b[1], 1.0)
        for i in range(4):
            self.line(0.08 * i, 0.1 * i, 0.08 * i, 1 - 0.1 * i, 0.5)
            self.line(1 - 0.08 * i, 0.1 * i, 1 - 0.08 * i, 1 - 0.1 * i, 0.5)
        self.head(0.5, 0.58, 0.2)
        self.body(0.5, 0.44, 0.22, 0.0)

    # ---- setas e anotações em vermelho ----
    def block_arrow(self, x, y, ang, size=0.2):
        c = self.canv
        L = size * self.w
        shape = [(0, 0.18), (0.55, 0.18), (0.55, 0.42), (1.0, 0.0), (0.55, -0.42), (0.55, -0.18), (0, -0.18)]
        ca, sa = math.cos(math.radians(ang)), math.sin(math.radians(ang))
        pa = c.beginPath()
        for i, (u, v) in enumerate(shape):
            px, py = self.X(x) + (u * ca - v * sa) * L, self.Y(y) + (u * sa + v * ca) * L
            pa.moveTo(px, py) if i == 0 else pa.lineTo(px, py)
        pa.close()
        c.setFillColor(RED)
        c.setStrokeColor(colors.HexColor("#9E2219"))
        c.setLineWidth(0.6)
        c.drawPath(pa, stroke=1, fill=1)

    def curved_arrow(self):
        pts = self.arc_pts(0.55, 0.45, 0.28, 0.12, 200, 340)
        c = self.canv
        c.setStrokeColor(RED)
        c.setLineWidth(1.4)
        pa = c.beginPath()
        pa.moveTo(self.X(pts[0][0]), self.Y(pts[0][1]))
        for x, y in pts[1:]:
            pa.lineTo(self.X(x), self.Y(y))
        c.drawPath(pa, stroke=1, fill=0)
        ex, ey = pts[-1]
        tip = [(ex, ey + 0.05), (ex - 0.07, ey - 0.01), (ex + 0.05, ey - 0.02)]
        pa = c.beginPath()
        pa.moveTo(self.X(tip[0][0]), self.Y(tip[0][1]))
        for x, y in tip[1:]:
            pa.lineTo(self.X(x), self.Y(y))
        pa.close()
        c.drawPath(pa, stroke=1, fill=0)

    def camera_arrows(self):
        m = (self.movimento or "").lower()
        if "dolly zoom" in m:
            m = "zoom out"
        if any(t in m for t in ("zoom in", "push", "aproxima", "fecha")):
            for x, y, ang in ((0.02, 0.98, -45), (0.98, 0.98, -135), (0.02, 0.02, 45), (0.98, 0.02, 135)):
                self.block_arrow(x, y, ang)
            return True
        elif any(t in m for t in ("zoom out", "pull", "afasta", "abre")):
            for x, y, ang in ((0.17, 0.83, 135), (0.83, 0.83, 45), (0.17, 0.17, -135), (0.83, 0.17, -45)):
                self.block_arrow(x, y, ang)
            return True
        elif any(t in m for t in ("pan", "travel", "lateral", "esquerda", "direita", "whip")):
            left = "para a esquerda" in m
            self.block_arrow(0.72 if left else 0.28, 0.24, 180 if left else 0, 0.3)
        elif any(t in m for t in ("tilt", "sobe", "desce")):
            down = "desce" in m
            self.block_arrow(0.85, 0.62 if down else 0.38, -90 if down else 90, 0.26)
        elif any(t in m for t in ("gira", "orbita", "arco", "curva", "acompanha")):
            self.curved_arrow()
        return False

    def red_note(self, text, x, y_top, max_w, size=7.5, angle=-3):
        if not text:
            return
        c = self.canv
        words, lines, cur = text.upper().split(), [], ""
        for wd in words:
            trial = (cur + " " + wd).strip()
            if c.stringWidth(trial, MARKER, size) > max_w * self.w and cur:
                lines.append(cur)
                cur = wd
            else:
                cur = trial
        lines.append(cur)
        c.saveState()
        c.translate(self.X(x), self.Y(y_top))
        c.rotate(angle)
        c.setFont(MARKER, size)
        for i, ln in enumerate(lines):
            c.setFillColor(colors.white)
            c.setFillAlpha(0.6)
            tw = c.stringWidth(ln, MARKER, size)
            c.rect(-1, -i * size * 1.15 - 1.5, tw + 2, size + 1, stroke=0, fill=1)
            c.setFillAlpha(1)
            c.setFillColor(RED)
            c.drawString(0, -i * size * 1.15, ln)
        c.restoreState()

    def draw(self):
        c = self.canv
        c.saveState()
        c.setFillColor(colors.white)
        c.rect(0, 0, self.w, self.h, stroke=0, fill=1)
        pa = c.beginPath()
        pa.rect(0, 0, self.w, self.h)
        c.clipPath(pa, stroke=0, fill=0)
        c.setLineCap(1)
        c.setLineJoin(1)
        getattr(self, "draw_" + self.plano)()
        if self.plano == "texto_tela" and self.tela:
            size = 11 if len(self.tela) < 18 else 8.5
            words, lines, cur = self.tela.upper().split(), [], ""
            for wd in words:
                trial = (cur + " " + wd).strip()
                if c.stringWidth(trial, MARKER, size) > self.w * 0.76 and cur:
                    lines.append(cur)
                    cur = wd
                else:
                    cur = trial
            lines.append(cur)
            c.setFillColor(INK)
            c.setFont(MARKER, size)
            y0 = self.Y(0.5) + (len(lines) - 1) * size * 0.55 - size * 0.35
            for i, ln in enumerate(lines):
                c.drawCentredString(self.w / 2, y0 - i * size * 1.1, ln)
        corners = self.camera_arrows()
        x0, w0 = (0.2, 0.66) if corners else (0.07, 0.84)
        self.red_note(self.anotacao, x0, 0.86 if corners else 0.9, w0)
        if self.movimento:
            self.red_note("CAM: " + self.movimento, x0, 0.2 if corners else 0.13, w0, size=6.5, angle=2)
        c.restoreState()
        c.setStrokeColor(INK)
        c.setLineWidth(1.2)
        c.rect(0, 0, self.w, self.h, stroke=1, fill=0)


def visual_cell(parte, seed, width, horizontal=False):
    vis = parte.get("visual") or {}
    if isinstance(vis, str):
        vis = {"descricao": vis}
    plano = vis.get("plano", "plano_medio")
    info = [Paragraph(escape((vis.get("take") or PLANO_NOMES.get(plano, plano)).upper()), S["visplano"]), Spacer(1, 2),
            p(vis.get("descricao") or parte.get("cena", ""), S["vis"])]
    if vis.get("movimento"):
        info += [Spacer(1, 3), Paragraph("<b>Câmera:</b> " + escape(vis["movimento"]), S["note"])]
    if horizontal:
        sketch = Sketch(plano, vis.get("anotacao"), vis.get("movimento"), parte.get("tela"), seed,
                        width=width, horizontal=True)
        return [sketch, Spacer(1, 5)] + info
    sketch = Sketch(plano, vis.get("anotacao"), vis.get("movimento"), parte.get("tela"), seed)
    gap = 4 * mm
    t = Table([[sketch, info]], colWidths=[sketch.w + gap, width - sketch.w - gap])
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                           ("RIGHTPADDING", (0, 0), (-1, -1), 0), ("TOPPADDING", (0, 0), (-1, -1), 0),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 0)]))
    return t


def speech_cell(parte):
    """Fala com as copies (texto que aparece na tela) em vermelho."""
    out = [p(parte.get("rotulo", ""), S["label"]), Spacer(1, 4)]
    if parte.get("gancho_visual"):
        out += [Paragraph("GANCHO VISUAL", S["hooktag"]), Spacer(1, 1),
                p(parte["gancho_visual"], S["speech"]), Spacer(1, 5),
                Paragraph("GANCHO DA FALA", S["hooktag"]), Spacer(1, 1)]
    if parte.get("tela"):
        out += [Paragraph("COPY: " + escape(parte["tela"].upper()), S["copy"]), Spacer(1, 3)]
    for line in (parte.get("fala") or "").split("\n"):
        if line.strip().upper().startswith("COPY:"):
            out.append(Paragraph(escape(line.strip().upper()), S["copy"]))
        else:
            out.append(p(line, S["speech"]))
    return out


def header(data, w):
    out = [Paragraph("ROTEIROS COLLAB", S["kicker"]), Spacer(1, 3),
           p(data.get("titulo") or data.get("tema", ""), S["title"]), Spacer(1, 10)]
    blocks = [("CONCEITO", data.get("conceito") or data.get("ideia_central")),
              ("IDEIA DO VÍDEO", data.get("ideia") or data.get("descricao"))]
    for label, text in blocks:
        if not text:
            continue
        box = Table([[Paragraph(label, S["infolabel"])], [p(text, S["desc"])]], colWidths=[w])
        box.setStyle(TableStyle([("LINEBEFORE", (0, 0), (0, -1), 3, ACCENT), ("LEFTPADDING", (0, 0), (-1, -1), 10),
                                 ("TOPPADDING", (0, 0), (-1, 0), 2), ("BOTTOMPADDING", (0, -1), (-1, -1), 3),
                                 ("TOPPADDING", (0, 1), (-1, 1), 2), ("BOTTOMPADDING", (0, 0), (-1, 0), 0)]))
        out += [box, Spacer(1, 8)]
    info = [("DURAÇÃO DO VÍDEO", data.get("duracao")),
            ("FORMATO DE GRAVAÇÃO", data.get("gravacao") or "Vertical (9:16)"),
            ("ESTILO", data.get("formato")), ("PARCEIRO", data.get("parceiro")),
            ("DATA", date.today().strftime("%d/%m/%Y"))]
    info = [(k, v) for k, v in info if v]
    cells = [[Paragraph(k, S["infolabel"]) for k, _ in info], [p(v, S["infoval"]) for _, v in info]]
    t = Table(cells, colWidths=[w / len(info)] * len(info))
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), CARD), ("LINEAFTER", (0, 0), (-2, -1), 0.6, LINE),
                           ("LEFTPADDING", (0, 0), (-1, -1), 9), ("TOPPADDING", (0, 0), (-1, 0), 7),
                           ("BOTTOMPADDING", (0, -1), (-1, -1), 8), ("TOPPADDING", (0, 1), (-1, 1), 1),
                           ("BOTTOMPADDING", (0, 0), (-1, 0), 1)]))
    out += [Spacer(1, 2), t]
    return out


def build(data, out):
    doc = SimpleDocTemplate(out, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm,
                            topMargin=14 * mm, bottomMargin=16 * mm,
                            title="Roteiro: " + (data.get("titulo") or data.get("tema", "")))
    w = doc.width
    lw = w * 0.5
    rw = w - lw
    pad = 8
    horizontal = "horiz" in (data.get("gravacao") or "").lower()
    story = header(data, w)
    seed = 0
    for i, ato in enumerate(data.get("atos", [])):
        color = ACT_COLORS[i % 3]
        head = Table([[p(ato.get("nome", ""), S["act"])]], colWidths=[w])
        head.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), color), ("LEFTPADDING", (0, 0), (-1, -1), 10),
                                  ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
        cols = Table([[Paragraph("FALA", S["colhead"]), Paragraph("REFERÊNCIA VISUAL", S["colhead"])]],
                     colWidths=[lw, rw])
        cols.setStyle(TableStyle([("LEFTPADDING", (0, 0), (-1, -1), pad), ("TOPPADDING", (0, 0), (-1, -1), 5),
                                  ("BOTTOMPADDING", (0, 0), (-1, -1), 3), ("LINEBELOW", (0, 0), (-1, 0), 0.6, LINE)]))
        rows = []
        for parte in ato.get("partes", []):
            seed += 1
            row = Table([[speech_cell(parte), visual_cell(parte, seed, rw - 2 * pad, horizontal)]], colWidths=[lw, rw])
            row.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"),
                                     ("LEFTPADDING", (0, 0), (-1, -1), pad), ("RIGHTPADDING", (0, 0), (-1, -1), pad),
                                     ("TOPPADDING", (0, 0), (-1, -1), 8), ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
                                     ("LINEBEFORE", (1, 0), (1, 0), 0.6, LINE), ("LINEBEFORE", (0, 0), (0, 0), 3, color),
                                     ("LINEBELOW", (0, 0), (-1, 0), 0.6, LINE)]))
            rows.append(row)
        story.append(Spacer(1, 14))
        story.append(KeepTogether([head, cols] + rows[:1]))
        story += [KeepTogether([r]) for r in rows[1:]]

    def footer(canvas, d):
        canvas.saveState()
        canvas.setStrokeColor(LINE)
        canvas.line(d.leftMargin, 11 * mm, d.leftMargin + d.width, 11 * mm)
        canvas.setFont("Helvetica", 7.5)
        canvas.setFillColor(MUTED)
        canvas.drawString(d.leftMargin, 7.5 * mm, "Roteiros Collab  ·  " + (data.get("titulo") or data.get("tema", "")))
        canvas.drawRightString(d.leftMargin + d.width, 7.5 * mm, str(d.page))
        canvas.restoreState()

    doc.build(story, onFirstPage=footer, onLaterPages=footer)


if __name__ == "__main__":
    with open(sys.argv[1], encoding="utf-8") as f:
        build(json.load(f), sys.argv[2])
