---
name: roteiros-collab
description: Cria roteiros de vídeo curtos (Reels/TikTok/Shorts) sobre um tema usando a estrutura de 3 atos da Collab (Gancho até Fim), e entrega o roteiro escrito no chat e em PDF com storyboard. Use quando o usuário pedir "Roteiros Collab" ou um roteiro de vídeo sobre algum tema.
---

# Roteiros Collab

## Quando usar
Sempre que o usuário disser "Roteiros Collab", "usa a skill Roteiros Collab" ou pedir um roteiro de vídeo sobre um tema.

## O que perguntar antes (só se faltar)
Se o pedido já tiver o tema, comece direto. Pergunte no máximo uma vez, e só o que faltar:
- Tema do vídeo (obrigatório)
- Duração desejada (padrão: 60 a 90 segundos)
- Marca ou parceiro da collab, se houver
- Formato de gravação: vertical (9:16) ou horizontal (16:9). Padrão: vertical

## Estrutura padrão: arco de 3 atos
Todo roteiro é uma pequena história com tensão subindo até o clímax e caindo rápido até o fim. Use estas partes, nesta ordem, com estes rótulos:

### 1º ATO: Apresentação
1. **Gancho** (até 5s), sempre como **gancho duplo**: dois ganchos ao mesmo tempo, montando uma armadilha de atenção.
   - **Gancho visual**: o que o olho vê no primeiro segundo, antes de qualquer palavra. Algo inesperado, em movimento ou fora do lugar (câmera dentro de um objeto, algo caindo na lente, um ângulo estranho, uma ação no meio). Precisa funcionar no mudo.
   - **Gancho da fala**: a primeira frase, que promete algo, provoca curiosidade ou contradiz uma crença ("Você não procrastina porque é preguiçoso").
   - Os dois se reforçam: o visual prende o olho e a fala dá o motivo para ficar. Nunca entregue um gancho só falado ou só visual.
2. **Incidente inicial**: o que dá a partida na história. O problema, a situação ou o desejo aparece.
3. **Crise inicial**: a primeira dificuldade. Mostra por que isso não é simples.

### 2º ATO: Conflito
4. **Obstáculos** (Desenvolvimento 1, 2, 3...): cada desenvolvimento é um obstáculo ou tentativa. A tensão sobe a cada um.
5. **Grande virada**: a descoberta, a ideia ou a mudança que muda o rumo.
6. **Desastre**: logo após a virada, algo ainda dá errado ou fica mais difícil.
7. **Crise**: o ponto mais tenso antes da resolução. A pergunta "vai dar certo?" fica no ar.

### 3º ATO: Resolução
8. **Clímax**: o momento de maior impacto. A solução, a revelação ou o resultado.
9. **Desfecho**: as consequências e a lição, de forma curta.
10. **Fim / CTA**: fechamento rápido e a chamada para ação (seguir, comentar, salvar, conhecer o parceiro).

Regras do arco:
- O 1º e o 2º ato sobem devagar; o 3º ato cai rápido. Depois do clímax, não enrole.
- Em vídeos curtos, partes podem ser uma única frase. Nenhuma parte pode ser pulada sem motivo; se juntar duas, diga quais.
- O 2º ato é o maior. Ajuste o número de Desenvolvimentos à duração (cerca de 1 a cada 15s).

Antes de escrever, defina em uma linha a **ideia central** (o que o espectador deve entender no clímax) e o **formato**.

Para cada parte, escreva:
- **Fala**: o texto exato a ser falado, linha por linha.
- **Na tela**: legenda ou elemento visual (opcional).
- **Referência visual** (obrigatória): o take criativo (da biblioteca), a descrição da cena e o movimento de câmera.

## Formatos de vídeo (escolha um)
O arco de 3 atos vale para todos. O formato muda como ele é contado. Se o usuário não disser, escolha o que combina com o tema e diga qual escolheu.

- **Mini-filme com metáfora:** uma cena de ficção (uma ligação, uma investigação, um diálogo) que representa o problema do público. A virada revela o que a metáfora significa. A marca entra só no desfecho. Bom para collabs de produto ou ferramenta.
- **Teoria em passos:** narração em off que abre com "A minha teoria é que..." e segue em Passo um, Passo dois, Passo três. Pode ter cara de série ("Episódio X: como ..."). O produto entra como parte natural de um dos passos e volta no clímax como a razão de tudo.
- **Aula com história:** fala direto para a câmera. Gancho com pergunta de dor, uma história real ou experimento com data, nome e números, o conceito ganha nome, aplicação no dia a dia do espectador, quebra de expectativa e teste prático antes do CTA. Bom para conteúdo educativo e venda de oferta.

## Takes criativos (obrigatório)
Escolha os takes na biblioteca `references/takes-criativos.md` (técnicas do site Eyecannndy adaptadas para Reels, com o que é, quando usar e como gravar com celular). Regras:
1. Todo roteiro usa **pelo menos 4 takes diferentes** da biblioteca.
2. O **gancho sempre** abre com um take criativo, que é a base do gancho visual, (POV do objeto, quebra da quarta parede, ângulo de minhoca, snorricam, olho de peixe ou uma transição), nunca com um close parado comum.
3. **Nunca o mesmo take duas vezes seguidas.** No máximo 2 closes simples de fala no vídeo inteiro.
4. A **grande virada** usa, de preferência, uma transição: portal de objeto, atravessar, whip pan, match cut ou dolly zoom.
5. O take precisa reforçar a fala (ex.: falar de tarefa adiada com a câmera dentro da gaveta), não ser enfeite.

Takes da biblioteca, em resumo: POV do objeto, quebra da quarta parede, ângulo de minhoca, snorricam, olho de peixe, crash zoom, de cima (top-down), Lazy Susan, por cima do ombro, tela dentro da tela, tela dividida, duplicação, reflexo, silhueta, mudança de escala, tipografia, whip pan, atravessar, portal de objeto, match cut, dolly zoom, speed ramp, freeze frame e câmera fixa.

## Padrões das referências
Tirados dos vídeos de referência (detalhes em `references/estruturas-referencia.md`):
1. **Gancho em até 5s**, criando identificação ou dor, sempre com texto na tela reforçando (meme, pergunta em letras grandes ou frase-teoria).
2. **Uma ideia central escondida** que só fica clara no clímax. Escreva a ideia central antes do roteiro e construa tudo para chegar nela.
3. **2º ato em blocos curtos**: passos numerados, perguntas e respostas ou etapas de um experimento. Cada bloco sobe a tensão.
4. **Prova concreta** quando o tema permitir: data, nome, número, resultado (ex.: "lembrado em 100% das vezes contra 22%").
5. **Quebra de expectativa no clímax**: algo que o espectador não esperava ("diferente não é ser esquisito", "a pessoa desaparecida é você").
6. **Marca ou oferta como consequência da história**, nunca como abertura. Se entrar cedo, entra como detalhe natural da cena.
7. **Fim rápido**: uma frase de assinatura e um CTA simples (comentar uma palavra, assinatura do produto ou convite para a oferta).
8. **Linguagem falada**: frases curtas, segunda pessoa ("você", "tu"), sem jargão. Pensadas para legenda palavra por palavra.

## Entrega (sempre as duas coisas)
1. **No chat**: o roteiro completo por escrito. No topo, nesta ordem: título do vídeo, conceito, ideia do vídeo, duração do vídeo e formato de gravação (vertical ou horizontal). Depois os 3 atos (o Gancho com GANCHO VISUAL e GANCHO DA FALA separados), com cada parte rotulada (Gancho, Incidente inicial, ..., Fim / CTA), a fala, o texto na tela e a referência visual.
2. **PDF em storyboard**: gere o PDF e entregue o arquivo para download. Nome: `roteiro-<tema-resumido>.pdf`.

## Layout do PDF (storyboard)
- **Topo (informações iniciais, sempre antes do roteiro), nesta ordem:** **TÍTULO DO VÍDEO** em cima de tudo; depois **CONCEITO** (a ideia central em uma frase); **IDEIA DO VÍDEO** (2 ou 3 frases sobre o que acontece no vídeo); e uma faixa com **DURAÇÃO DO VÍDEO**, **FORMATO DE GRAVAÇÃO** (vertical 9:16 ou horizontal 16:9), estilo e data.
- **Corpo, em duas colunas, separado por ato** (faixa colorida com o nome do ato: azul, vermelho, verde):
  - **Esquerda, FALA:** o rótulo da parte e a fala, linha por linha. Sempre que algo precisar aparecer escrito na tela (gancho visual, número, nome de conceito, CTA), coloque a copy em **vermelho e negrito** no ponto da fala onde ela entra, no formato `COPY: POR QUE VOCÊ PROCRASTINA?`.
  - **Direita, REFERÊNCIA VISUAL:** um quadro vertical 9:16 no estilo de storyboard feito à mão: traço preto de nanquim, sombras com marcador cinza, anotação da ação escrita à mão em vermelho no alto do quadro, anotação de câmera ("CAM: ...") em vermelho embaixo e setas vermelhas mostrando o movimento de câmera (quatro setas nos cantos apontando para dentro = zoom in / push in; para fora = zoom out; seta lateral = pan; seta vertical = tilt; seta curva = câmera gira ou acompanha). Ao lado do quadro: o nome do plano, a descrição da cena, o movimento de câmera e o texto na tela.

Planos disponíveis para o desenho: `close_rosto`, `close_olho`, `plano_medio`, `plano_geral`, `maos_objeto`, `celular`, `texto_tela`, `arquivo`, `grafico`, `dialogo`, `objeto`, e os takes criativos `pov_objeto`, `quarta_parede`, `minhoca`, `snorricam`, `olho_de_peixe`, `de_cima`, `ombro`, `tela_dividida`, `duplicacao`, `reflexo`, `silhueta`, `escala`, `whip_pan`, `portal_objeto`, `dolly_zoom`.

## Como gerar o PDF
Monte um JSON com o roteiro e rode o script `scripts/gerar_pdf.py` que acompanha esta skill (usa a biblioteca `reportlab`, que desenha os quadros do storyboard):

```
python scripts/gerar_pdf.py roteiro.json roteiro-<tema>.pdf
```

Formato do JSON:
```json
{
  "titulo": "Título do vídeo",
  "conceito": "A ideia central em uma frase: o que o espectador entende no clímax.",
  "ideia": "Duas ou três frases sobre o que acontece no vídeo.",
  "duracao": "70 a 80s",
  "gravacao": "Vertical (9:16)",
  "formato": "Aula com história",
  "parceiro": "Marca da collab (opcional)",
  "atos": [
    {"nome": "1º ATO: Apresentação", "partes": [
      {"rotulo": "Gancho (gancho duplo)",
       "gancho_visual": "O que o olho vê no primeiro segundo, sem som.",
       "fala": "Texto falado.\nUma linha por frase.",
       "tela": "Texto na tela",
       "visual": {"take": "POV do objeto (de dentro da gaveta)", "plano": "pov_objeto", "anotacao": "Abre a gaveta e encara", "descricao": "A câmera está dentro da gaveta; a pessoa abre e fala com a lente.", "movimento": "Câmera parada dentro da gaveta"}}
    ]},
    {"nome": "2º ATO: Conflito", "partes": []},
    {"nome": "3º ATO: Resolução", "partes": []}
  ]
}
```

`gancho_visual` só existe no Gancho e aparece na coluna da fala como GANCHO VISUAL, seguido do GANCHO DA FALA. `tela` é a copy que aparece escrita na tela: vai em vermelho como `COPY: ...` na coluna da fala. Para uma copy no meio da fala, escreva uma linha começando com `COPY:` dentro de `fala`. Com `gravacao` horizontal, os quadros do storyboard saem em 16:9.

Em `visual`, `take` é o nome do take da biblioteca (aparece como título da referência visual), `plano` escolhe o desenho, `anotacao` é a ação em poucas palavras (vai escrita em vermelho no quadro) e `movimento` define as setas de câmera. A fonte das anotações fica em `assets/PermanentMarker.ttf`.

Se o script não estiver disponível, reproduza o mesmo layout com o gerador de PDF que tiver: traço preto grosso, sombra cinza, anotações e setas em vermelho.

Um exemplo pronto está em `exemplo/roteiro-procrastinacao.json` e `exemplo/roteiro-procrastinacao.pdf`.
