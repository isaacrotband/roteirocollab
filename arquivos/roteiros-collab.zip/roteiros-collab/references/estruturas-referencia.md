# Estruturas dos vídeos de referência

Roteiros reconstruídos a partir das legendas dos vídeos (as falas podem ter pequenas diferenças do áudio original). Cada vídeo está encaixado no arco de 3 atos da skill.

---

## Referência A: "Desaparecimento" (collab Mag.IA, ~83s)
**Formato:** mini-filme de ficção com metáfora. O produto só aparece no fim, como revelação.

### 1º ATO: Apresentação
- **Gancho (0 a 5s):** texto na tela em formato de meme, com a pessoa no sofá: "Quando eu escolho o filme e me sinto responsável como se eu tivesse escrito, gravado e dirigido ele." Logo depois entram créditos de cinema ("um oferecimento de..., dirigido por..., editado por..."), avisando que vai começar um filme.
- **Incidente inicial:** ligação para a polícia. "Qual é a sua denúncia?" / "Oi, eu queria registrar um desaparecimento."
- **Crise inicial:** "Onde essa pessoa foi vista pela última vez?" / "Provavelmente em um café, lendo aquele livro que ela prometeu terminar há dois meses."

### 2º ATO: Conflito
- **Obstáculo 1 (Desenvolvimento 1):** ela sai pela rua perguntando "Moça, com licença, você conhece essa pessoa?" e ninguém conhece.
- **Obstáculo 2 (Desenvolvimento 2):** "O que essa pessoa costumava fazer quando ainda aparecia?" / "Ela escrevia, conversava..." / "Essa resposta foi um pouco genérica. Seja mais específica."
- **Grande virada:** "Ela gostava de fazer as pessoas pensarem. Via alguma coisa comum e enxergava o que ninguém percebia." / "Excelente resposta."
- **Crise:** "Agora, a última pergunta: quando foi a última vez que você viu essa pessoa?" Ela trava e percebe.

### 3º ATO: Resolução
- **Clímax:** "Agora eu entendi o seu ponto." / "Pessoa localizada." / "Como?" A desaparecida era ela mesma, a versão criativa dela.
- **Desfecho:** "Bem-vinda de volta, Giullya." Entra a marca: "A IA que não cria no seu lugar. Ela encontra você no seu conteúdo. Mag.IA."
- **Fim / CTA:** texto na tela "A inteligência artificial para quem tem sede da inteligência humana" e "Comente EU QUERO".

**O que é mais forte:** a metáfora (a pessoa desaparecida é a sua própria voz criativa) e a virada final, que faz o espectador se reconhecer. As perguntas do "atendente" são as mesmas que a IA faz, então o produto é demonstrado sem parecer anúncio.

---

## Referência B: "Como criar qualquer coisa em qualquer lugar" (collab ASUS Zenbook Duo, ~62s)
**Formato:** narração em off com uma teoria e passos numerados, em formato de série ("Episódio 4"). O produto faz parte da história desde o passo 1.

### 1º ATO: Apresentação
- **Gancho:** "A minha teoria é que criatividade não é um lugar, mas um lugar que muda o tempo todo."
- **Incidente inicial:** "E quem quiser criar tem que aprender a encontrar." Aparece o caderno: "Episódio 4: como criar qualquer coisa em qualquer lugar."
- **Crise inicial:** (implícita) a criatividade some se você fica preso a um lugar só.

### 2º ATO: Conflito
- **Desenvolvimento 1 (Passo um):** "A partir de hoje, teu escritório é: um caderno, uma caneta, carteira, um fone todo embolado, uma [coisa] esquecida há três dias e um ASUS Zenbook. O resto o mundo costuma dar."
- **Desenvolvimento 2 (Passo dois):** "Nunca diga 'depois eu anoto'. As ideias têm um costume: elas aparecem e desaparecem muito rápido. Elas vão pro que eu chamo de buraco negro das ideias."
- **Grande virada:** "A única forma de evitar que isso aconteça é anotar a ideia imediatamente. Então anota isso."
- **Desenvolvimento 3 (Passo três):** "Não pensa muito. Se pensar, tu vai achar motivo pra não fazer. Então pega e só faz: no café, no banco da praça, na praia. E olha a tua volta."
- **Crise / reflexão:** "Porque cada lugar é uma nova inspiração."

### 3º ATO: Resolução
- **Clímax:** "E criatividade não tá num lugar. É uma conversa entre você e o mundo."
- **Desfecho:** "E é por isso que eu gosto de trabalhar no ASUS Zenbook Duo. Porque quando o mundo muda, o meu escritório muda junto. E assim eu posso criar qualquer coisa em qualquer lugar."
- **Fim / CTA:** assinatura do produto: "ASUS Zenbook Duo. Dupla produtividade, máxima mobilidade."

**O que é mais forte:** o gancho em forma de teoria pessoal, os passos curtos e práticos, e o produto entrando como parte natural da lista do passo 1, voltando no clímax como a razão de tudo.

---

## Referência C: "Por que seus vídeos são ignorados?" (talking head educativo, ~131s)
**Formato:** aula com uma história real e um experimento. Fala direto para a câmera, com cortes para imagens de época, gráficos e uma cena de filme.

### 1º ATO: Apresentação
- **Gancho:** texto grande na tela "Por que seus vídeos SÃO IGNORADOS?" e a fala "Você com certeza viu diversos vídeos hoje, mas não lembra de quase nenhum."
- **Incidente inicial:** "E isso provavelmente explica..." (abre a promessa de explicação).
- **Crise inicial:** "Em 1933, uma pesquisadora alemã chamada Hedwig von Restorff fez um teste muito simples."

### 2º ATO: Conflito
- **Desenvolvimento 1 (o experimento):** "Ela mostrava para as pessoas uma lista de oito duplas, cada dupla aparecia por 2 segundos. Quatro duplas eram sílabas sem sentido. As outras eram diferentes entre si: números, letras, símbolos, cores."
- **Desenvolvimento 2 (o teste):** "Depois ela conversava alguns minutos sobre outro assunto e pedia para lembrar o que tinha visto. Os itens diferentes eram muito mais lembrados que as sílabas parecidas."
- **Grande virada (os dados):** "Ela resolveu apertar esse teste. Montou uma lista com 19 sílabas e um único número. Em experimentos com 84 crianças, o item diferente foi lembrado em 100% das vezes. Os parecidos, apenas 22%."
- **Desastre:** "Hedwig identificou o que mudaria a maneira como entendemos a memória: quando recebemos muitas informações semelhantes, elas começam a competir entre si." O conceito ganha nome na tela: "ISSO = VON RESTORFF". "Isso está nos livros de psicologia até hoje."
- **Crise (aplicação no espectador):** "Agora pensa no feed. Você provavelmente assistiu vários e não se lembra da maioria. A maioria das pessoas cria conteúdo olhando para os outros, copiando o formato, o roteiro, praticamente o vídeo. Logo, já nasce dessa lista de sílabas."

### 3º ATO: Resolução
- **Clímax:** "Só que ser diferente também não quer dizer fazer qualquer coisa esquisita para chamar atenção. Se a pessoa não se lembra do que você falou, a dancinha não ajudou em nada o seu negócio. Precisa ser diferente na opinião, a sua opinião sobre aquilo que todo mundo no mercado está falando igual."
- **Desfecho (teste prático):** "Então, se você colocasse o seu vídeo no meio de dez outras pessoas da sua área, ele seria lembrado?"
- **Fim / CTA:** "Se a resposta for não, é exatamente o que eu vou mostrar na minha oferta: como criar conteúdos que vendem e permanecem na memória das pessoas. Te vejo lá. Até a próxima."

**O que é mais forte:** a pergunta-dor no gancho, a prova com dados reais (100% contra 22%), a quebra de expectativa no clímax ("diferente não é esquisito") e o teste que o espectador faz sozinho antes do CTA.

---

## Padrões em comum
1. O gancho cria identificação ou dor em menos de 5 segundos, sempre com texto na tela reforçando.
2. Existe uma "ideia central" que só fica clara no clímax (a pessoa desaparecida é você; criatividade é uma conversa com o mundo; diferente não é esquisito).
3. O 2º ato avança em blocos curtos e numerados ou em perguntas e respostas.
4. A marca ou oferta aparece como consequência da história, nunca no começo. Na B ela entra cedo, mas como item natural da lista.
5. O fim é rápido: uma frase de assinatura e um CTA simples (comente uma palavra, assinatura do produto ou convite para a oferta).
6. Frases curtas, faladas, com legenda palavra por palavra ou frase por frase.
