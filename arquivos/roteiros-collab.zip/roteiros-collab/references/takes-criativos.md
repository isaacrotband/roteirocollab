# Biblioteca de takes criativos

Técnicas tiradas da biblioteca do site Eyecannndy (eyecannndy.com), escolhidas por funcionarem em vídeo vertical e serem possíveis de gravar com celular ou uma câmera simples. O nome em inglês é o mesmo usado no site, para facilitar a busca de exemplos lá.

Cada take tem o código de `plano` que gera o desenho no storyboard.

## Ganchos (primeiros 3 segundos)
| Take | O que é | Quando usar | Como gravar | plano |
|---|---|---|---|---|
| **POV do objeto** (Object POV) | A câmera é o objeto: de dentro da geladeira, da gaveta, da caneca, da mochila. | Abrir o vídeo com estranhamento; mostrar o produto "vendo" a pessoa. | Celular dentro do objeto, lente para fora. | `pov_objeto` |
| **Quebra da quarta parede** (Fourth Wall) | A pessoa fala com a câmera de forma física: tapa a lente, puxa a câmera, aponta. | Gancho direto, interromper o scroll. | Mão vai até a lente; corte quando cobre a tela. | `quarta_parede` |
| **Ângulo de minhoca** (Worm's-Eye) | Câmera no chão olhando para cima. A pessoa fica gigante. | Entrada com poder, revelação de personagem. | Celular deitado no chão, lente para cima. | `minhoca` |
| **Snorricam** | Câmera presa ao corpo, rosto fixo no centro e o mundo balançando atrás. | Mostrar ansiedade, pressa, caos mental. | Selfie stick preso ao peito ou braço esticado travado, andando. | `snorricam` |
| **Olho de peixe** (Fisheye) | Lente ultra grande angular, rosto distorcido e bem perto. | Humor, energia, estética street. | Lente 0,5x do celular bem perto do rosto. | `olho_de_peixe` |
| **Crash zoom / zoom brusco** (Zoom) | Zoom rápido e seco no rosto ou objeto. | Reação, ênfase numa palavra. | Zoom na edição (keyframe de 2 a 4 frames). | qualquer plano + movimento "zoom in" |

## Desenvolvimento (ritmo e informação)
| Take | O que é | Quando usar | Como gravar | plano |
|---|---|---|---|---|
| **De cima** (Overhead / top-down) | Câmera no teto olhando para baixo: mesa, mãos, objetos. | Passos, listas, processo, "o que tem na mochila". | Celular num tripé com braço ou preso numa prateleira. | `de_cima` |
| **Lazy Susan** | Câmera no centro da mesa girando de pessoa em pessoa ou de objeto em objeto. | Apresentar itens ou personagens em sequência. | Celular num prato giratório ou girando no tripé. | `de_cima` ou `dialogo` + movimento "gira" |
| **Por cima do ombro** (Over the Shoulder) | Ombro e nuca em primeiro plano, a outra pessoa ou tela ao fundo. | Diálogos, mostrar o que a pessoa vê. | Câmera atrás do ombro, foco no fundo. | `ombro` |
| **Tela dentro da tela** (Screen in Screen) | A cena aparece dentro de uma tela: celular, notebook, TV. | Falar de redes sociais, feed, notificações. | Gravar a tela ou montar na edição. | `celular` |
| **Tela dividida** (Split Screen) | Duas cenas lado a lado ou uma em cima da outra. | Antes e depois, certo e errado, duas versões de você. | Montar na edição. | `tela_dividida` |
| **Duplicação** (Duplication) | A mesma pessoa aparece várias vezes no quadro. | Mostrar vozes internas, várias tarefas, "todo mundo faz igual". | Tripé fixo, gravar várias vezes e mascarar na edição. | `duplicacao` |
| **Reflexo** (Reflections) | A cena é vista por um espelho, vidro, tela desligada ou poça. | Momento de autoanálise, virada interna. | Filmar o espelho, não a pessoa. | `reflexo` |
| **Silhueta** (Silhouette) | Pessoa toda escura contra uma luz forte (janela, pôr do sol). | Mistério, história real, momento dramático. | Expor para a janela, sem luz na pessoa. | `silhueta` |
| **Mudança de escala** (Scale Shift) | Objetos gigantes e pessoas minúsculas, ou o contrário. | Mostrar um problema "grande demais", metáforas. | Perspectiva forçada ou montagem. | `escala` |
| **Gráfico / tipografia** (Typography, Floating UI) | Texto ou dado na tela como protagonista. | Números, nomes de conceitos. | Edição. | `grafico` ou `texto_tela` |

## Viradas e transições
| Take | O que é | Quando usar | Como gravar | plano |
|---|---|---|---|---|
| **Whip pan** | Giro rápido da câmera com borrão, emendando duas cenas. | Mudar de lugar ou de tempo de forma rápida. | Girar o celular rápido no fim de um take e no começo do outro. | `whip_pan` |
| **Atravessar** (Pass Through) | A câmera passa por dentro de algo: buraco, fechadura, alça, vão. | Entrar num flashback, numa história, num "mundo". | Aproximar a lente até cobrir o buraco e cortar. | `portal_objeto` |
| **Portal de objeto** (Object Portal) | Um objeto vira a porta para outra cena (o fundo da caneca, a tela, um óculos). | Grande virada, mudança de assunto. | Zoom no objeto até preencher a tela e cortar. | `portal_objeto` |
| **Match cut** | Corte entre duas cenas diferentes ligadas por forma ou movimento igual. | Ligar ideias (um olho vira a lua, um café vira um buraco). | Planejar o mesmo enquadramento nos dois takes. | qualquer plano |
| **Dolly zoom** | Câmera anda para trás enquanto dá zoom: o fundo "estica". | A ficha caindo, a percepção. | Andar para trás com zoom in ao mesmo tempo, ou efeito na edição. | `dolly_zoom` |
| **Speed ramp** | O vídeo acelera e desacelera no meio do movimento. | Dar energia e marcar a batida. | Gravar em 60fps e mexer na velocidade. | qualquer plano |
| **Freeze frame** | A imagem congela e algo é apontado ou explicado. | Destacar um detalhe, um "repara nisso". | Edição. | qualquer plano |
| **Plano com câmera parada** (Fixed Cam / Locked-On) | Câmera travada enquanto o mundo se mexe. | Contraste com cenas agitadas, pausa dramática. | Tripé. | `plano_medio` |

## Regras de uso na skill
1. Todo roteiro usa **pelo menos 4 takes diferentes** desta biblioteca.
2. O **gancho sempre** usa um take da seção Ganchos ou de transição, nunca um close parado comum.
3. **Nunca o mesmo take duas vezes seguidas.** No máximo 2 closes simples de fala no vídeo inteiro.
4. A **grande virada** usa, de preferência, uma transição: portal de objeto, atravessar, whip pan, match cut ou dolly zoom.
5. Cada take precisa fazer sentido com a fala (o take reforça a ideia, não é enfeite).
